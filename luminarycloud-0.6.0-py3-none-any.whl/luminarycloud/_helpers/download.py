# Copyright 2023-2024 Luminary Cloud, Inc. All Rights Reserved.
import errno
import logging
import os
from pathlib import Path
import requests
from typing import Iterator, Optional, Union, cast

from .file_chunk_stream import FileChunkStream
from .._proto.api.v0.luminarycloud.common import common_pb2 as commonpb
from .._proto.api.v0.luminarycloud.solution.solution_pb2 import (
    GetSolutionSurfaceDataRequest,
    GetSolutionVolumeDataRequest,
)
from .._client import Client

logger = logging.getLogger(__name__)


def _get_fetch_url(primary_domain: str, file_id: str) -> str:
    """
    Get the URL for the fetch endpoint given a domain
    and file ID.
    """
    return f"https://{primary_domain}/fetch/{file_id}"


def _iter_file_id(
    client: Client,
    file_id: str,
) -> Iterator[bytes]:
    """
    Iterator for download via the fetch endpoint using a file ID.
    """
    if not client.primary_domain:
        raise ValueError("Client does not support file download.")
    fetch_url = _get_fetch_url(client.primary_domain, file_id)
    headers = {"Authorization": f"Bearer {client.get_token()}"}
    r = requests.get(fetch_url, headers=headers, verify=(not client.internal), stream=True)
    # 4MiB chunk size.  Maybe tune.
    for chunk in r.iter_content(chunk_size=4 * 1024 * 1024):
        yield chunk


def _iter_url(
    client: Client,
    url: str,
) -> Iterator[bytes]:
    """Iterator for download via URL."""
    headers = {}
    # Sometimes we use the gcsproxy to proxy downloads. In that case, the backend requires us to
    # authenticate. However, if we are directly downloading from GCS, we should not expose the auth
    # token to the GCS server.
    if "storage.googleapis.com" not in url:
        headers = {"Authorization": f"Bearer {client.get_token()}"}
    r = requests.get(url, headers=headers, verify=(not client.internal), stream=True)
    # 4MiB chunk size.  Maybe tune.
    for chunk in r.iter_content(chunk_size=4 * 1024 * 1024):
        yield chunk


def download_surface_solution(
    client: Client,
    solution_id: str,
) -> FileChunkStream:
    """
    Returns the download as a file-like object.

    The filename can be retrieved from the `filename` attribute of the returned object.

    Examples
    --------
    >>> with download_surface_solution(client, "your-solution-id") as dl:
    ...     with open(dl.filename, "wb") as fp:
    ...         fp.write(dl.read())
    """

    request = GetSolutionSurfaceDataRequest(id=solution_id)
    response = client.GetSolutionSurfaceData(request)
    file = response.file

    if file.signed_url:
        logger.info(f"Begin streaming surface data via signed URL for solution {solution_id}.")
        return FileChunkStream(file.metadata, _iter_url(client, file.signed_url))

    logger.info(f"Begin streaming surface data via fetch URL for solution {solution_id}.")
    return FileChunkStream(file.metadata, _iter_file_id(client, file.file_id))


def download_volume_solution(
    client: Client,
    solution_id: str,
) -> FileChunkStream:
    """
    Returns the download as a file-like object.

    The filename can be retrieved from the `filename` attribute of the returned object.

    Examples
    --------
    >>> with download_volume_solution(client, "your-solution-id") as dl:
    ...     with open(dl.filename, "wb") as fp:
    ...         fp.write(dl.read())
    """

    request = GetSolutionVolumeDataRequest(id=solution_id)
    response = client.GetSolutionVolumeData(request)
    file = response.file

    if file.signed_url:
        logger.info(f"Begin streaming volume data via signed URL for solution {solution_id}.")
        return FileChunkStream(file.metadata, _iter_url(client, file.signed_url))

    logger.info(f"Begin streaming volume solution via fetch URL for solution {solution_id}.")
    return FileChunkStream(file.metadata, _iter_file_id(client, file.file_id))


def save_file(
    file_proto: commonpb.File,
    dest_dir: Union[os.PathLike, str],
    *,
    filename: Optional[str] = None,
) -> None:
    """
    Saves the file to the given directory.

    Parameters
    ----------
    file_proto: commonpb.File
        Contents must be of type full_contents.
    dest_dir: PathLike or str
        The destination directory.
    filename: str
        (Optional) The desired filename. Extension is appended if omitted.

    Raises
    ------
    FileNotFoundError
        If the directory does not exist.
    OSError
        If a file with the same name already exists.

    Examples
    --------
    >>> res = client.GetSimulationSurfaceQuantityOutput(req)
    >>> save_file(res.csv_file, "~/Downloads")
    """
    metadata = file_proto.metadata
    if filename is None:
        filename = metadata.name
    if "." not in filename:
        if len(metadata.ext) > 0:
            filename += "." + metadata.ext

    dest_path = Path(dest_dir) / cast(str, filename)
    if os.path.exists(dest_path):
        err = OSError(errno.EEXIST, "File already exists at location", str(dest_path))
        logger.error("File not found.", exc_info=err)
        raise err

    logger.info(f"Writing file to {dest_path}")
    with open(dest_path, "w+") as fp:
        fp.write(file_proto.full_contents.decode())
