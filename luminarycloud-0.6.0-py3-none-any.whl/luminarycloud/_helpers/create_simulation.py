# Copyright 2023-2024 Luminary Cloud, Inc. All Rights Reserved.
import logging
from os import PathLike
from typing import Optional, Union

from google.protobuf import json_format

from .._proto.fvm.param_pb2 import Param as FvmParam
from .._proto.client.simulation_pb2 import SimulationParam
from .._proto.api.v0.luminarycloud.simulation.simulation_pb2 import (
    Simulation,
    SimulationOptions,
    CreateSimulationRequest,
)
from .._client import Client

logger = logging.getLogger(__name__)


def create_simulation(
    client: Client,
    *,
    project_id: str = "",
    mesh_id: str = "",
    name: str = "",
    description: str = "",
    simulation_params_json_path: Optional[Union[PathLike, str]] = None,
    batch_processing: bool = False,
) -> Simulation:

    if simulation_params_json_path is None:
        msg = "Missing simulation params json path."
        logger.exception(msg)
        raise ValueError(msg)

    logger.debug(f"Reading simulation params from file: {simulation_params_json_path}")
    with open(simulation_params_json_path, "rb") as fp:
        params_json_bytes = fp.read()

    logger.debug(f"Calling gRPC CreateSimulation with project_id {project_id}, mesh_id {mesh_id}")
    response = client.CreateSimulation(
        CreateSimulationRequest(
            project_id=project_id,
            mesh_id=mesh_id,
            name=name,
            description=description,
            simulation_options=SimulationOptions(batch_processing=batch_processing),
            simulation_param_json=params_json_bytes,
        )
    )
    return response.simulation
