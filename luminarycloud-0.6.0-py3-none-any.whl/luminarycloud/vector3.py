# Copyright 2023-2024 Luminary Cloud, Inc. All Rights Reserved.
from ._proto.api.v0.luminarycloud.common import common_pb2 as commonpb


class Vector3:
    """Represents a 3-dimensional vector."""

    x: float
    y: float
    z: float

    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

    def _to_proto(self) -> commonpb.Vector3:
        return commonpb.Vector3(x=self.x, y=self.y, z=self.z)
