# Copyright 2023-2024 Luminary Cloud, Inc. All Rights Reserved.
from datetime import datetime
from os import PathLike
from typing import List, Optional, Union

from .mesh import Mesh
from .simulation import Simulation
from .enum import MeshType

from ._wrapper import ProtoWrapper, ProtoWrapperBase
from ._client import get_default_client
from ._helpers import (
    create_simulation,
    timestamp_to_datetime,
    upload_mesh,
)
from ._proto.api.v0.luminarycloud.project import project_pb2 as projectpb
from ._proto.api.v0.luminarycloud.simulation import simulation_pb2 as simulationpb
from ._proto.api.v0.luminarycloud.mesh import mesh_pb2 as meshpb


@ProtoWrapper(projectpb.Project)
class Project(ProtoWrapperBase):
    """Represents a Project object."""

    id: str
    name: str
    description: str
    storage_usage_bytes: int

    _proto: projectpb.Project

    @property
    def create_time(self) -> datetime:
        return timestamp_to_datetime(self._proto.create_time)

    @property
    def update_time(self) -> datetime:
        return timestamp_to_datetime(self._proto.update_time)

    def update(
        self,
        *,
        name: str = "",
        description: str = "",
    ) -> None:
        """
        Update/Edit project attributes.

        Mutates self.

        Parameters
        ----------
        name : str
            (Optional) New project name.
        description : str
            (Optional) New project description.
        """
        req = projectpb.UpdateProjectRequest(
            id=self.id,
            name=name,
            description=description,
        )
        res = get_default_client().UpdateProject(req)
        self._proto = res.project

    def delete(self) -> None:
        """
        Delete the project.
        """
        req = projectpb.DeleteProjectRequest(
            id=self.id,
        )
        get_default_client().DeleteProject(req)

    def upload_mesh(
        self,
        path: Union[PathLike, str],
        *,
        name: Optional[str] = None,
        scaling: Optional[float] = None,
        chunk_size: Optional[int] = None,
        mesh_type: Optional[MeshType] = None,
        do_not_read_zones_openfoam: Optional[bool] = None,
    ) -> Mesh:
        """
        Upload mesh to project.

        For supported formats, see: https://docs.luminarycloud.com/en/articles/9275233-upload-a-mesh

        Parameters
        ----------
        path : pathlike or str
            Path or URL to the mesh file to upload.
        name : str
            (Optional) Name of the mesh resource on Luminary Cloud. Defaults to
            the filename without the extension.
        scaling : float
            (Optional) If set, apply a scaling factor to the mesh.
        chunk_size : int
            (Optional) Number of bytes per uploaded chunk. Default size is 1 MB.
        mesh_type : MeshType
            (Optional) The file format of the mesh file. Required for OpenFOAM format.
        do_not_read_zones_openfoam : bool
            (Optional) If true, disables reading cell zones in the polyMesh/cellZones file
            for OpenFOAM meshes. Default false.
        """
        _mesh = upload_mesh(
            get_default_client(),
            project_id=self.id,
            path=path,
            mesh_type=mesh_type,
            name=name,
            scaling=scaling,
            chunk_size=chunk_size,
            do_not_read_zones_openfoam=do_not_read_zones_openfoam,
        )
        return Mesh(_mesh)

    def list_meshes(self) -> List[Mesh]:
        """
        List all meshes in project.
        """
        req = meshpb.ListMeshesRequest(project_id=self.id)
        res = get_default_client().ListMeshes(req)
        return [Mesh(m) for m in res.meshes]

    def create_simulation(
        self,
        mesh_id: str,
        name: str,
        params_json_path: Union[PathLike, str],
        *,
        batch_processing: bool = False,
        description: str = "",
    ) -> Simulation:
        """
        Create a new simulation.

        Parameters
        ----------
        mesh_id : str
            Mesh ID.
        name : str
            Simulation name. If empty, a default name will be generated.
        description : str
            (Optional) Simulation description.
        params_json_path : path-like
            Path to local JSON file containing simulation params.
        batch_processing : bool
            (Optional) If True, batch processing will be used for this
            simulation. Defaults to False.

            Use Batch Processing on simulations that are not time-sensitive to
            save up to 65% in credits.
        """
        _simulation = create_simulation(
            get_default_client(),
            project_id=self.id,
            mesh_id=mesh_id,
            name=name,
            description=description,
            simulation_params_json_path=params_json_path,
            batch_processing=batch_processing,
        )
        return Simulation(_simulation)

    def list_simulations(self) -> List[Simulation]:
        """
        List all simulations in project.
        """
        req = simulationpb.ListSimulationsRequest(project_id=self.id)
        res = get_default_client().ListSimulations(req)
        return [Simulation(s) for s in res.simulations]


def create_project(
    name: str,
    description: str = "",
) -> Project:
    """
    Create a project owned by the user.

    Parameters
    ----------
    name : str
        Project name.
    description : str
        Project description.
    """
    req = projectpb.CreateProjectRequest(name=name, description=description)
    res = get_default_client().CreateProject(req)
    return Project(res.project)


def get_project(
    id: str,
) -> Project:
    """
    Get a specific project by ID.

    Parameters
    ----------
    id : str
        Project ID.
    """
    req = projectpb.GetProjectRequest(id=id)
    res = get_default_client().GetProject(req)
    return Project(res.project)


def list_projects() -> List[Project]:
    """
    List projects accessible by the user.
    """
    req = projectpb.ListProjectsRequest()
    res = get_default_client().ListProjects(req)
    return [Project(p) for p in res.projects]
