# Copyright 2023-2024 Luminary Cloud, Inc. All Rights Reserved.

from typing import Optional

from .client import Client

_default_client: Optional[Client] = None


def set_default_client(client: Client) -> None:
    """
    Set the default client object used by wrappers.

    This may be useful for setting custom options or mocking the client for testing.

    Examples
    --------
    >>> options = [("grpc.keepalive_time_ms", 800)]
    >>> client = Client(grpc_channel_options=options)
    >>> set_default_client(client)
    """
    global _default_client
    _default_client = client


def get_default_client() -> Client:
    """
    Get the default client object used by wrappers.
    """
    global _default_client
    if _default_client is None:
        _default_client = Client()
    return _default_client
