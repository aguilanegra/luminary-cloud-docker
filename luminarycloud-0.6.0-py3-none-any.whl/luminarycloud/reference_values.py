# Copyright 2024 Luminary Cloud, Inc. All Rights Reserved.
from ._proto.base.base_pb2 import AdFloatType
from ._proto.output import reference_values_pb2 as refvalpb
from .enum import ReferenceValuesType


class ReferenceValues:
    """
    Reference values needed for computing forces, moments and other
    non-dimensional output quantities.
    """

    reference_value_type: ReferenceValuesType
    """
    Method of specification for the reference values used in force and moment
    computations. Default: PRESCRIBE_VALUES
    """

    area_ref: float
    "Reference area for computing force and moment coefficients. Default: 1.0"

    length_ref: float
    "Reference length for computing moment coefficients. Default: 1.0"

    p_ref: float
    """
    Absolute static reference pressure for computing force and moment
    coefficients. This value is independent of the simulation reference
    pressure. Default: 101325.0
    """

    t_ref: float
    """
    Reference temperature for computing force and moment coefficients.
    Default: 288.15
    """

    v_ref: float
    """
    Reference velocity magnitude for computing force and moment coefficients.
    Default: 1.0
    """

    def __init__(
        self,
        reference_value_type: ReferenceValuesType = ReferenceValuesType.PRESCRIBE_VALUES,
        area_ref: float = 1.0,
        length_ref: float = 1.0,
        p_ref: float = 101325.0,
        t_ref: float = 288.15,
        v_ref: float = 1.0,
    ) -> None:
        self.reference_value_type = reference_value_type
        self.area_ref = area_ref
        self.length_ref = length_ref
        self.p_ref = p_ref
        self.t_ref = t_ref
        self.v_ref = v_ref

    def _to_proto(self) -> refvalpb.ReferenceValues:
        return refvalpb.ReferenceValues(
            reference_value_type=self.reference_value_type.value,
            area_ref=AdFloatType(value=self.area_ref),
            p_ref=AdFloatType(value=self.p_ref),
            t_ref=AdFloatType(value=self.t_ref),
            v_ref=AdFloatType(value=self.v_ref),
        )
